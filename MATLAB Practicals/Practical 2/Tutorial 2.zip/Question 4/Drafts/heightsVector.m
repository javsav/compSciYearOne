% This program reads in the inputs of heights of 5 students in centimetres,
% stores them in a vector and then displays the output of each height on a
% new line.

heights = zeros([1 5])