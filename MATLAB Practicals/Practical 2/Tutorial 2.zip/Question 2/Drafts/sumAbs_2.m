% This is a program that asks the user to input 5 negative or positive
% numbers, then outputs the sum of the absolute value of each of the
% numbers

% Defines empty array of 5x1 of integer 0 (as we are going to sum those
% values together, we can add them to 0)

sumlist = zeros([1 5])

% Prompt user for numerical inputs

inputdlg = ("Please enter five numbers (positive or negative) for which you would like \nto calculate the sum of their absolute values ", num1, num2, num3, num4, num5)